// Configuration provided by the user
export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyDcbs_h9FlmT02EEyOUez4bf0nOb3vcQG8",
  authDomain: "bios-2d8ca.firebaseapp.com",
  databaseURL: "https://bios-2d8ca-default-rtdb.firebaseio.com",
  projectId: "bios-2d8ca",
  storageBucket: "bios-2d8ca.firebasestorage.app",
  messagingSenderId: "40622594695",
  appId: "1:40622594695:web:unknown" // Inferred standard format
};

export const GOOGLE_MAPS_API_KEY = "";
export const GEMINI_API_KEY = "";

// Collection name in Firestore
export const COLLECTION_NAME = "problems";
